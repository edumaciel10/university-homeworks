public  class Divida {
    private float valor;

    public Divida(float dividaTotal) {
        this.valor = dividaTotal;
    }

    public float getDividaTotal() {
        return valor;
    }
}
