Para rodar o programa, digite: javac Main.java && java Main
