public class SistemaDecorator {
  FilterSistema fsASerDecorado;

  public SistemaDecorator(FilterSistema fsASerDecorado) {
    this.fsASerDecorado = fsASerDecorado;
  }
}
