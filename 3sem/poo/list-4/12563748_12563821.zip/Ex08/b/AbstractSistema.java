public abstract class AbstractSistema {
  public abstract String ();
  public abstract float getPreco();
}