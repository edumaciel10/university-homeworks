interface FilterSistema {
    public String lerDados(String s);
    public String[] lerArray(String[] s);
}
