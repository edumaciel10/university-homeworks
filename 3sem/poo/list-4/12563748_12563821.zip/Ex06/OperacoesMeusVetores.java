public interface OperacoesMeusVetores {
    void fazOperacao(MeusVetores vetores);
}
