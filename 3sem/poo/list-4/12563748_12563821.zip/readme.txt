Para rodar os digite os seguintes comandos:
javac Main.java
java Main