public interface JurosBase {
    float calculaJurosTotal(Divida divida);
}
