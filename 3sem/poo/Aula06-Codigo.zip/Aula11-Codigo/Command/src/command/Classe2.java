package command;


/**
 *
 * @author Junio
 */
public class Classe2 extends Comando{

    public void Comportamento() {
        System.out.println("CLASSE2 - Mas não sei o que faço durante, so sei que farei alguma coisa.");
    }

}
