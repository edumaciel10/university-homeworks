package chainofresponsibility;
/**
 *
 * @author Junio
 */
public class JogadaDeExcecao {
    private int iCode;

    public JogadaDeExcecao(int iCode) {
        this.iCode = iCode;
    }

    public int getCode() {
        return iCode;
    }

}
