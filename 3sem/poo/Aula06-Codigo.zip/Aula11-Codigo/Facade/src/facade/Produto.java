/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package facade;

/**
 *
 * @author Junio
 */
public class Produto {
    int iId;

    public int getiId() {
        return iId;
    }

    public void setiId(int iId) {
        this.iId = iId;
    }
}
