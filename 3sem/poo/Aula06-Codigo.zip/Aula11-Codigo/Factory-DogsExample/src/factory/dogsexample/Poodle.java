/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package factory.dogsexample;

/**
 *
 * @author http://alvinalexander.com/java/java-factory-pattern-example
 */
class Poodle implements Dog
{
  public void speak()
  {
    System.out.println("The poodle says \"arf\"");
  }
}