/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package factory.dogsexample;

/**
 *
 * @author http://alvinalexander.com/java/java-factory-pattern-example
 */
class Rottweiler implements Dog
{
  public void speak()
  {
    System.out.println("The Rottweiler says (in a very deep voice) \"WOOF!\"");
  }
}