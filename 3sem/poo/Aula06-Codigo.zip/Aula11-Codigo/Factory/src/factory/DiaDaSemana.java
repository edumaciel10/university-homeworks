package factory;

/**
 *
 * @author Junio
 */
public abstract class DiaDaSemana {
    private String sNome;
    public abstract String getsNome();
}
