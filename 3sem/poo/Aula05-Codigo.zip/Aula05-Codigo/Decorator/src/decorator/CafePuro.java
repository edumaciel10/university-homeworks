package decorator;

/**
 *
 * @author Junio
 */
public class CafePuro extends Cafe{
    public String getDescricao(){
        return "Cafe puro";
    }
    public float getPreco() {
        return 0.5f;
    }

}
