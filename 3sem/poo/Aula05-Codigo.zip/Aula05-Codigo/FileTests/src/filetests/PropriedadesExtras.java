/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package filetests;

import java.io.Serializable;

/**
 *
 * @author junio
 */
public class PropriedadesExtras implements Serializable {
    int i;
    int j;
    int o;
}
