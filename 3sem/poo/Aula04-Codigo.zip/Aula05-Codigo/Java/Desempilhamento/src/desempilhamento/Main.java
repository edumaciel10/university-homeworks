/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package desempilhamento;

/**
 *
 * @author Junio
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Auxiliar aux = new Auxiliar();
        //aux.stackOverFlow();
        //return;        
        //try {
            int i = aux.metodo1();
        //} catch (Exception e) {
            System.out.println("Erro!");
            /*Disclaimer: apenas para fins de demonstração
            JAMAIS peguem um nullpointer exception!!!*/
        //}
        //...
        //aux.metodo3();
        //...
        //aux.metodo5();
        System.out.println("APLICACAO FINALIZADA");
    }
}
