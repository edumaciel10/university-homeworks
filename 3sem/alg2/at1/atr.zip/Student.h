#ifndef TADGENERICO_ARVOREBINARIA_H
#define TADGENERICO_ARVOREBINARIA_H

typedef struct student STUDENT;


void printStudent(const STUDENT *s);

#endif //TADGENERICO_ARVOREBINARIA_H
