Arquivo zip gerado em: 19/09/2021 01:11:49 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 02 - Catálogo de jogos