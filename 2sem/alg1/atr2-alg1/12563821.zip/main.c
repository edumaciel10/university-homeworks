#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "game.h"
#include "catalog.h"
#include "utils.h"

int main() {
  GAME *games = createEmptyGames();
  int sizeOfGames = 0;
  games = getGames(games, &sizeOfGames);
  // return 0;
  CATALOG *catalog = createEmptyCatalog();
  catalog = getCatalogWithFilters(catalog, games,sizeOfGames);
  printCatalog(catalog);
  return 0;
}
