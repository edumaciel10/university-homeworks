Arquivo zip gerado em: 17/10/2021 14:32:24 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Atividade avaliativa 05 - Métodos de ordenação: Shell e Quick