Arquivo zip gerado em: 28/09/2021 23:13:24 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Atividade avaliativa 02 - Métodos de ordenação: Inserção e Merge