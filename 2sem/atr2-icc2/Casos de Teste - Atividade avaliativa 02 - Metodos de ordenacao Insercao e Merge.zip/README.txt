Arquivo zip gerado em: 25/09/2021 20:15:00 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Atividade avaliativa 02 - Métodos de ordenação: Inserção e Merge